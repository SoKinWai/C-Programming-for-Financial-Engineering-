﻿//Level 7: Overview of the Standard Template Library​
//Exercise 1: STL Containers
//Create a list of doubles and add some data. Use the front() and back() functions to access the first and last element.
//Create a vector of doubles and add some data. Then use the index operator to access some elements. Also make the vector grow.
//Create a map that maps strings to doubles. Fill the map and access elements using the square bracket operator.

#include <stdlib.h>
#include <string>
#include <iostream>
#include <list>
#include <vector>
#include <map>
using namespace std;

void main()
{
	//Create a list of doubles and add some data.
	list<double> list;

	//Use the front() and back() functions to access the first and last element.
	list.push_front(2);					//If the next one does not exist, the first element should be 2.
	list.push_front(5);					//This should be the first element.
	list.push_back(6);					//If the last two elements do not exist, the first element should be 6.
	list.push_back(7);					//This should be the last element.
	

	//Test the list.
	cout << "Test the list." << endl;
	cout << "The first element:"<<list.front() << endl;
	cout << "The last element:" << list.back() << endl;
	cout << "The size:" << list.size() << endl << endl;				//Should be 4. There are 4 elements I created.   
	list.clear();

	//Create a vector of doubles and add some data.
	vector<double> vector;

	vector.reserve(3);					//The reserve space is 3.
	vector.push_back(2);				//Add the first element.
	vector.push_back(4);				//Add the last element.

	//Test the vector
	cout << "Test the vector." << endl;
	cout << "The size before the vector grows:" << vector.size() << endl;
	cout << "The capacity before the vector grows:" << vector.capacity() << endl;
	cout << "The first element before the vector grows:" << vector[0] << endl;				//Use the index operator to access some elements
	cout << "The last element before the vector grows:" << vector.back()/*or use vector[1]*/ << endl;
	
	//Make the vector grow.
	vector.push_back(5);
	vector.push_back(6);
	cout << "The size after the vector grows:" << vector.size() << endl;
	cout << "The capacity after the vector grows:" << vector.capacity() << endl;
	cout << "The first element after the vector grows:" << vector[0] << endl;				//Use the index operator to access some elements
	cout << "The last element after the vector grows:" << vector[3] /*or use vector.back()*/ << endl << endl;

	vector.clear();

	//Create a map that maps strings to doubles.
	map<string, double> map;

	//Fill the map and access elements using the square bracket operator.
	map.insert(make_pair<string, double>("This", 5));				//Insertion:insert()
	map["is"] = 6;
	map["the"] = 7;
	map["map"] = 8;

	//Test the map
	cout << "Test the map." << endl;
	cout << "The size:" << map.size() << endl;
	cout <<"This:"<< map["This"]<< endl;
	cout << "is:" << map["is"] << endl;
	cout << "the:" << map["the"] << endl;
	cout << "map:" << map["map"]<< endl;
	map.clear();

	cout << endl;






}


















