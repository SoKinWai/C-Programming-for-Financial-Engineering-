﻿//Level 7:Overview of the Standard Template Library​
//Exercise 3: STL Algorithms


#ifndef Smaller_than_HPP
#define Smaller_than_HPP
#include<iostream>
using namespace std;

template <typename T>
class Smaller_than
{
private:
	T m;

public:
	//Constructors
	Smaller_than();													//Default constructor
	Smaller_than(const T& s);										//Initialize with s	
	Smaller_than(const Smaller_than<T>& source);					//Copy constructor

	~Smaller_than();												//Destructor

	
	//Member opeartors overloading
	
	//Assignment operator.
	Smaller_than<T>&operator =(const Smaller_than<T>& source);


	//Bracket operator
	bool operator()(const T& source) const;

};

#ifndef Smaller_than_CPP 
#include "Smaller_than.cpp"
#endif


#endif 
