﻿//Level 7:Overview of the Standard Template Library​
//Exercise 3: STL Algorithms

#ifndef Smaller_than_CPP
#define Smaller_than_CPP

#include "Smaller_than.hpp"
using namespace std;

template <typename T>
Smaller_than<T>::Smaller_than() :m(10)												//Default constructor
{

}

template <typename T>
Smaller_than<T>::Smaller_than(const T& s) :m(s)										//Initialize with s	
{

}

template <typename T>
Smaller_than<T>::Smaller_than(const Smaller_than<T>& source) :m(source.m)			//Copy constructor
{

}

template <typename T>
Smaller_than<T>::~Smaller_than()													//Destructor
{

}

template <typename T>
Smaller_than<T>& Smaller_than<T>::operator=(const Smaller_than<T>& source)			//Assignment operator
{
	if (this == &source)
	{
		return *this;
	}

	m = source.m;

	return *this;
}

template <typename T>
bool Smaller_than<T>::operator()(const T& source) const								//Bracket operator
{
	return(source < m);
}

#endif













 
