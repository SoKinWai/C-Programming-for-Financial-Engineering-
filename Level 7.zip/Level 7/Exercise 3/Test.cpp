﻿//Level 7:Overview of the Standard Template Library​
//Exercise 3: STL Algorithms
//Test program


#include <vector>
#include <list>
#include <algorithm>
#include <iostream>
#include "Smaller_than.hpp"
using namespace std;


//A global function that checks the double input is smaller than a certain value.
bool smaller(const double input)
{
	double certain_value = 10;
	return (input < certain_value);
}

void main()
{
	//Test the vector
	vector<double> Vector;																				//Create the vector
	for (int a = 1; a < 15;a++)
	{
		//Assign the vector elements with values. 
		Vector.push_back(a);																			
	}

	//Use the global function to show results
	int result_a = count_if(Vector.begin(), Vector.end(), smaller);										//Should be 9

	cout << "Test the vector:" << endl;
	cout << "The vector has " << result_a << " values less than 10." << endl << endl;


	//Test the list 
	list<double> List;																					//Create the list
	for (int b =7 ;b < 15;b++)
	{
		//Assign the list elements with values.
		List.push_back(b);

	}

	//Use the global function to show results
	int result_b = count_if(List.begin(), List.end(), smaller);											//Should be 3		 						

	cout << "Test the list:" << endl;
	cout << "The list has " << result_b << " values less than 10." << endl << endl;


	//Replace the global checking function, by a function object.

	//Test the vector by a function object
	int result_c = count_if(Vector.begin(),Vector.end(),Smaller_than<double>(6));						//Should be 5.
	
	cout << "Test the vector by a function object:" << endl;
	cout << "The vector has " << result_c << " values less than 6." << endl << endl;

	Vector.clear();

	//Test the list by a function obeject
	int result_d = count_if(List.begin(), List.end(), Smaller_than<double>(9));							//Should be 2

	cout << "Test the list by a function object:" << endl;
	cout << "The list has " << result_d << " values less than 9." << endl << endl;


	List.clear();


}