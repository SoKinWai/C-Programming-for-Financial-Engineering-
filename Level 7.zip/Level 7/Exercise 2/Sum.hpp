﻿//Overview of the Standard Template Library​
//Exercise 2: STL Iterators
//Create a template function called Sum() that accepts the template argument T as input and returns a double. The template argument will be a container.
//In the implementation get an iterator (T::const_iterator) for the end. Then create a loop that iterates the container T and adds all values. Finally return the sum.

#ifndef Sum_HPP
#define Sum_HPP
#include <vector>
#include <list>
#include <map>
#include <string>
#include<iostream>
using namespace std;

//Sum of  all elements in a container for vector and list
template <typename T>
double Sum(const T& s)
{
	double sum = 0;
	typename T::const_iterator i;

	for (i = s.begin();i != s.end();i++)				//Iteration for container
	{
		sum += *(i);
	}

	return sum;
}

//Sum of all elements in a map
template<typename T_1, typename T_2>
double Sum(const map<T_1, T_2>&s)
{
	double sum = 0;
	typename map<T_1, T_2>::const_iterator i;

	for (i = s.begin();i != s.end();i++)				//Iteration for container
	{
		sum += (i->second);
	}

	return sum;
}

//Create a Sum() function that calculates the sum of all values between two passed-in iterators. 
//The function should use the template argument for the iterator type and accept two iterators, the 'start' - and 'end' iterator. 
//Sum of all elements between 2 iterators in a container for vector and list.
template <typename T>
double Sum(const T& start, const T& end)
{
	double sum = 0;
	T i;

	//Iteration for container
	for (i = start;i != end;i++)
	{
		sum += *(i);
	}

	return sum;

}

//Sum of all elements between 2 iterators in a map
template<typename T_1, typename T_2>
double Sum(const typename map<T_1, T_2>::const_iterator& start, const typename map<T_1, T_2>::const_iterator& end)
{
	double sum = 0;
	typename map<T_1, T_2>::const_iterator i;

	//Iteration for container
	for (i = start; i != end; i++)
	{
		sum += i->second;
	}

	return sum;

}

#endif