﻿//Overview of the Standard Template Library​
//Exercise 2: STL Iterators
//In the main program, call the Sum() function for the different container from the previous exercise.
//Test program.

#include "Sum.hpp"
#include <map>
#include<list>
#include<vector>
#include<iostream>
#include<string>
using namespace std;

void main()
{
	//Test the list
	list<double> l;												//Create a list 
	l.push_back(3);												//Add an element in the back
	l.push_front(4);											//Add an element in the front
	l.push_back(5);												//Add an element in the back

	cout << "Test the list." << endl;
	cout << "The first element:" << l.front() << endl;
	cout << "The last element:" << l.back() << endl;
	cout << "The size:" << l.size() <<endl;
	cout << "The sum of the list:" << Sum(l) << endl;			//The sum should be 12.

	list<double>::const_iterator l_start = l.begin();			//The first iterator
	list<double>::const_iterator l_end = l.end();				//The second iterator 
	cout << "The sum of two iterators for the list: " << Sum(l_start, l_end) << endl << endl;

	l.clear();

	//Test the vector
	vector<double> v;											//Create a vector
	v.reserve(6);												//Reserve the space for 3

	v.push_back(6);												//Add an element
	v.push_back(7);												//Add an element
	v.push_back(8);												//Add an element

	//Test the vector
	cout << "Test the vector." << endl;
	cout << "The size:" << v.size() << endl;
	cout << "The capacity:" << v.capacity() << endl;
	cout << "The first element of the vector:" << v[0] << endl;				//Use the index operator to access some elements
	cout << "The last element of the vector:" << v.back()/*or use vector[1]*/ << endl;
	cout << "The sum of the vector:" << Sum(v) << endl;

	vector<double>::const_iterator v_start = v.begin();			//The first iterator
	vector<double>::const_iterator v_end = v.end();				//The second iterator 
	cout << "The sum of two iterators for the vector: " << Sum(v_start, v_end) << endl << endl;

	v.clear();

	//Test the map
	map<string, double> m;										//Create a map that maps strings to doubles.

	//Fill the map and access elements using the square bracket operator.
	m.insert(make_pair<string, double>("This", 5));				//Insertion:insert()
	m["is"] = 6;
	m["the"] = 7;
	m["map"] = 8;

	//Test the map
	cout << "Test the map." << endl;
	cout << "The size:" << m.size() << endl;
	cout << "This:" << m["This"] << endl;
	cout << "is:" << m["is"] << endl;
	cout << "the:" << m["the"] << endl;
	cout << "map:" << m["map"] << endl;

	cout << "The sum of the map is:" << Sum(m) << endl;
	
	map<string, double>::const_iterator m_1 = m.begin();		//The first iterator
	map<string, double>::const_iterator m_2 = m.end();			//The second iterator 
	
	cout << "The sum of two iterators of map: " << Sum<string, double>(m_1, m_2) << endl;
	
	m.clear();

	cout << endl;

}