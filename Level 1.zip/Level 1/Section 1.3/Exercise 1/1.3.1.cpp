#include <stdio.h>

int main() {
	/* my first program in C */
	printf("My first C-program is a fact! Good, isn��t it ? \n");

	return 0;
}