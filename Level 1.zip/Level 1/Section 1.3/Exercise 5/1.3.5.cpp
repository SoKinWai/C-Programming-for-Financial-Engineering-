# include <stdio.h>

int main()
{
	int i=10;         
	int j = 10;
	int a;
	int b;
	
	
/*postfix operator*/
	a = i--;
	
	printf("value of a\n:%d",a);      /*Equivalent code: a=i; a equals 10.*/
	printf("value of i\n:%d", i);     /*Equivalent code:i=i-1;i equals 9.*/


	
	

	b = --j;
	printf("value of b\n:%d", b);      /*Equivalent code:b=j-1;b equals 9.*/
	printf("value of i\n:%d", j);       /*Equivalent code:j=j-1;j equals 9.*/
	
	








	return 0;
}