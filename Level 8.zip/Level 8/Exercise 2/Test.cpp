﻿//5.1 - An Introduction to the Boost C++ Libraries​
//Exercise 2: Tuple
//Create a typedef for a Person tuple that contains a name, age and height.
//Also create a function that prints the person tuple.
//Use the get<T>() member functions the retrieve the data. Create a few person tuple instances and print them.
//Also increment the age of one of the persons. 
//Note that to change a value of one of the tuple elements, you can also use the get<T>() function since it returns a reference to the value.
//Test program.

#include "boost/tuple/tuple.hpp"
#include "boost/tuple/tuple_io.hpp"
#include <string>
#include <iostream>
using namespace std;

//Create a typedef for a Person tuple that contains a name, age and height.
typedef boost::tuple <string, int, double> Person;


//Create a function that prints the person tuple.
void print(const Person& s)
{
	//Use the get<T>() member functions the retrieve the data. Create a few person tuple instances and print them.
	cout << "Name:"<<s.get<0>() << ", " << "age:"<<s.get<1>() << ". " <<"height(m):"<< s.get<2>() <<". "<< endl;
}

void main()
{
	// Using declaration, for readability purposes
	using boost::tuple;

	

	//Create a few person tuple instances and print them.
	Person A = boost::make_tuple(string("Amy"), 17, 1.65);									//The first person
	//Person A (string("A"), 21, 1.77);
	Person B =boost::make_tuple(string("Bill"), 31, 1.85);									//The second person
	 Person C = boost::make_tuple(string("Cassie"), 26, 1.70);								//The third person
	 Person D = boost::make_tuple(string("Don"), 28, 1.75);									//The last person

	print(A);
	print(B);
	print(C);
	print(D);

	//Increment the age of one of the persons. 
	//Use the get<T>() function to change a value of one of the tuple elements since it returns a reference to the value.
	B.get<1>() +=4;

	cout <<endl<< "After increment of 4 years for B: " << endl;
	print(B);

}