﻿//5.1 - An Introduction to the Boost C++ Libraries​
//Exercise 3: Variant
//Test program.

#include <boost/variant.hpp>
#include "Point.hpp"
#include "Line.hpp"
#include "Circle.hpp"
#include "Visitor.hpp"
#include <iostream>
#include <string>
using namespace std;

//Create a typedef for a ShapeType variant that can contain a Point, Line or Circle. 
typedef boost::variant<Point, Line, Circle> ShapeType;

//Create a function that returns the variant. 
ShapeType type()
{
	//Within this function ask the user for the shape type to create. 
	cout << "Please choose a shape type from Point, Line or Circle. (Please enter one of Point, Line or Circle.)" << endl;
	string To_choose;
	cin >> To_choose;

	//Create the requested shape and assign it to the variant and return it.
	if (To_choose == "Point")
	{
		return Point(0, 0);
	}
	else if (To_choose == "Line")
	{
		return Line(Point(1, 2), Point(4, 9));
	}
	else if (To_choose == "Circle")
	{
		return Circle(Point(4, 0), 2);
	}
	else
	{
		cout << "This is an error." << endl;
	}
}

void main()
{
	using boost::variant;

	//Call the function and print the result by sending it to cout.
	ShapeType a = type();
	cout << a;								//It will print a point, a line or a circle.

											//Try to assign the variant to a Line variable by using the global boost:get<T>() function. 
											//This will throw a boost::bad_get exception when the variant didn’t contain a line.
	Line line = Line();

	try
	{
		line = boost::get<Line>(a);
	}
	catch (boost::bad_get& error)
	{
		cout << "This is an error:" << error.what() << endl;
	}

	//Create an instance of the visitor and use the boost::apply_visitor(visitor, variant) global function to move the shape. 
	//Print the shape afterwards to check if the visitor indeed changed the coordinates.
	Visitor visitor(5, 6);

	Point p_a(1, 1);
	variant<Point> point(p_a);
	cout << endl << "Test the point after move the shape." << endl;
	cout << "The original point:" << point << endl;
	boost::apply_visitor(visitor, point);
	cout << "The point after move the shape: " << point << endl << endl;

	Line l_a(Point(1, 0), Point(3, 0));
	variant<Line> l_b(l_a);
	cout << "Test the line after move the shape." << endl;
	cout << "The original line:" << l_b;
	boost::apply_visitor(visitor, l_b);
	cout << "The line after move the shape:" << l_b << endl << endl;

	Circle circle(Point(2, 3), 3);
	variant<Circle> c(circle);
	cout << "Test the circle after move the shape." << endl;
	cout << "The original circle:" << c;
	boost::apply_visitor(visitor, c);
	cout << "The circle after move the shape:" <<c<< endl;

}