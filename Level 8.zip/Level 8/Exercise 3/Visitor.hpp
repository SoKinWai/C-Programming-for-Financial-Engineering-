﻿//5.1 - An Introduction to the Boost C++ Libraries​
//Exercise 3: Variant
//Create a variant visitor that moves the shapes. 


#ifndef Visitor_HPP
#define Visitor_HPP
#include <boost/variant.hpp>
#include "Point.hpp"
#include "Line.hpp"
#include "Shape.hpp"
#include "Circle.hpp"
#include <sstream>
#include <iostream>
using namespace std;

//The visitor is derived from boost::static_visitor<void>.
class Visitor :public boost::static_visitor<void>
{
private:
	//x and y coordinates.
	double m_dx;
	double m_dy;

public:
	//Constructors
	//The visitor must have members for the x- and y-offset that are set in the constructor.
	Visitor();											//Default constructor
	Visitor(const Visitor& s);							//Copy constructor
	Visitor(double x,double y);							//Constructor accepts x and y coordinates

	~Visitor();											//Destructor

	Visitor& operator=(const Visitor& s);				//Assignment operator
	
	//For each shape, create an operator () that changes the coordinates of the shape. 
	void operator () (Point& p) const;					//Visit a point.
	void operator()(Line& l)const;						//Visit a line.
	void operator()(Circle& c) const;					//Visit a circle.

};

#endif 