﻿//5.1 - An Introduction to the Boost C++ Libraries​
//Exercise 3: Variant
//Create a variant visitor that moves the shapes. 

#ifndef Visitor_CPP
#define Visitor_CPP
#include<sstream>
#include "Visitor.hpp"

//Default constructor
Visitor::Visitor() :boost::static_visitor<void>()
{
	m_dx = 3;
	m_dy = 4;
}

//Copy constructor
Visitor::Visitor(const Visitor& s) :boost::static_visitor<void>(s)
{
	m_dx = s.m_dx;
	m_dy = s.m_dy;
}

//Constructor accepts x and y coordinates
Visitor::Visitor(double x, double y) :boost::static_visitor<void>()
{
	m_dx = x;
	m_dy = y;
}

//Destructor
Visitor::~Visitor()
{
}

//Assignment operator
Visitor& Visitor::operator=(const Visitor& s)
{
	if (this == &s)
	{
		return *this;
	}

	//Call the assignment operator of the base class. 
	Visitor::operator=(s);

	m_dx = s.m_dx;
	m_dy = s.m_dy;

	return *this;
}

//For each shape, create an operator () that changes the coordinates of the shape. 

// Visit a point.
void Visitor::operator () (Point& p) const
{
	p.X(p.X() + m_dx);
	p.Y(p.Y() + m_dy);
}

//Visit a line
void Visitor::operator()(Line& l) const
{
	l.P1(Point((l.P1()).X() + m_dx, (l.P1()).Y() + m_dy));
	l.P2(Point((l.P2()).X() + m_dx, (l.P2()).Y() + m_dy));
}

//Visit a circle
void Visitor::operator()(Circle& c)const
{
	c.CentrePoint(Point((c.CentrePoint()).X() + m_dx, (c.CentrePoint()).Y() + m_dy));
}

#endif