﻿//5.1 - An Introduction to the Boost C++ Libraries​
//Exercise 1: Smart Pointers
//Create a program that creates an array with shared pointers for shapes
//Test program

#include <vector>
#include "Array.hpp"
#include "Point.hpp"
#include "Line.hpp"
#include "Circle.hpp"
#include "Shape.hpp"
#include <iostream>
#include "boost/shared_ptr.hpp"

void main()
{
	
		// Typedef for a shared pointer to shape and
		// a typedef for an array with shapes stored as shared pointers.
		typedef boost::shared_ptr<Shape> ShapePtr;
		typedef Array<ShapePtr> ShapeArray;

		ShapePtr p_a(new Point(7, 3));
		ShapePtr p_b(new Line(Point(2, 3), Point(4, 5)));
		ShapePtr p_c(new Circle(Point(2, 3), 2));

		cout << "Reference count for point before filled with shapes: " << p_a.use_count() << endl;					//1
		cout << "Reference count for line before filled with shapes: " << p_b.use_count() << endl;					//1
		cout << "Reference count for circle before filled with shapes:" << p_c.use_count() << endl << endl;			//1
		{
			ShapeArray array(3);
			array[0] = p_a;
			array[1] = p_b;
			array[2]= p_c;
			
			cout << "With shapes:" << endl;
		
		cout << array[0]->ToString() << endl;
		cout << "Reference count for point after filled with shapes: " << p_a.use_count() << endl;				//2
		
		cout << array[1]->ToString() << endl;
		cout<< "Reference count for line after filled with shapes: " << p_b.use_count() << endl;				//2
		
		cout << array[2]->ToString() << endl;
		cout<< "Reference count for circle after filled with shapes: " << p_c.use_count() << endl<<endl;			//2
		}

		//Delete all shapes in the array explicitly.
		//The boost::shared_ptr<T> class stores a pointer and will delete the object automatically.
		//Check if the shapes are automatically deleted.
		cout << "Check if the shapes are automatically deleted" << endl;
		cout << "Referebce count for point:" << p_a.use_count() << endl;											//1
		cout << "Reference count for line:" << p_b.use_count() << endl;												//1
		cout << "Reference count for circle:" << p_c.use_count() << endl;											//1
}