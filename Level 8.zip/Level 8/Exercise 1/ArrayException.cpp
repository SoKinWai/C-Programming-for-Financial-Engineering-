﻿//5.1 - An Introduction to the Boost C++ Libraries​
//Exercise 1: Smart Pointers
//Create a program that creates an array with shared pointers for shapes

#include <sstream>
#include <cmath>
#include<stdlib.h>
#include<string>
#include<iostream>
#include "ArrayException.hpp"
using namespace std;

//A default constructor.
ArrayException::ArrayException()
{
}

//A destructor.
ArrayException::~ArrayException()
{
}