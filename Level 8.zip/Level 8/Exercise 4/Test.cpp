﻿//5.1 - An Introduction to the Boost C++ Libraries​
//Exercise 4: Random Number Generation
//Test program

#include <boost/random.hpp> // Convenience header file
#include <iostream>
#include <ctime>			// std::time
#include <boost/limits.hpp>
#include <map>
using namespace std;

void main()
{
	// Throwing dice.
	// Mersenne Twister.
	boost::random::mt19937 myRng;

	// Set the seed.
	myRng.seed(static_cast<boost::uint32_t> (std::time(0)));

	// Uniform in range [1,6]
	boost::random::uniform_int_distribution<int> six(1, 6);

	map<int, long> statistics; // Structure to hold outcome + frequencies
	int outcome; // Current outcome

	//Generate a large number of trials and place their frequencies in map.

	for (int a = 1;a <= 6;a++)
	{
		//Initialize map elements.
		statistics.insert(make_pair(a, 0));
	}

	cout << "How many trials?(Please enter an integer.)" << endl;
	long b;
	cin >> b;

	for (long c = 1;c <= b;c++)
	{
		//Generate one outcome
		outcome = six(myRng);

		statistics[outcome]++;
	}


	for (int d = 1;d <= 6;d++)
	{
		//Print the outcomes
		cout << "Trial " << d << " has " << double(statistics[d]) / double(b) * 100 << "% outcomes" << endl;
	}

}