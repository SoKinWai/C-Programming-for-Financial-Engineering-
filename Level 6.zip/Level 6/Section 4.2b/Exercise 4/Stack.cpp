﻿//4.2b - Advanced Templates​
//Exercise 4: Stack Class (composition)
//Create a template class called Stack. It is not a derived class but it uses an Array as data member. You also need a data member for the current index in the array.
//Create the regular constructors, destructor and assignment operator.
//Add a Push() function. It should store the element at the current position in the embedded array. Increment the current position afterwards. 
//There is no need for checking the current index because the array will throw an exception when the stack is full. Make sure the current index is not changed when the Array class threw an exception.
//Add a Pop() function that decrements the current position and then returns the element at that position. 
//Make sure the current index is not changed when the Array class throws an exception.

#ifndef Stack_CPP
#define Stack_CPP

#include "Stack.hpp"
#include "Array.hpp"
#include <iostream>

//Default constructor.
template<typename T>
Stack<T>::Stack() :m_current(0),d_m()
{
}

//Constructor accepts size
template<typename T>
Stack<T>::Stack(int s) : m_current(0), d_m(s)
{
}

//Copy constructor
template<typename T>
Stack<T>::Stack(const Stack<T>& ss) : m_current(ss.m_current), d_m(ss.d_m)
{
}

//Destructor
template<typename T>
Stack<T>::~Stack()
{
}

//An assignment operator.
template<typename T>
Stack<T>& Stack<T>:: operator = (const Stack<T>& source)
{
	if (this == &source)
	{
		return *this;
	}

	m_current = source.m_current;
	d_m = source.d_m;
	
	return *this;
}

//Add a Push() function
template<typename T>
void Stack<T>::Push(const T& push_e)
{
	//Store the element at the current position in the embedded array
	d_m[m_current] = push_e;

	//Increment the current position afterwards. 
	m_current++;
}

//Add a Pop() function
template<typename T>
const T& Stack<T>::Pop()
{
	d_m[m_current - 1];															
	m_current--;
	return d_m[m_current];
}

#endif