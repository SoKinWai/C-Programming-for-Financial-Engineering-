﻿//4.2b - Advanced Templates​
//Exercise 4: Stack Class (composition)
//The main function to test the stack.

#include <iostream>

#include "Array.hpp"							
#include "Stack.hpp"							
using namespace std;

void main()
{
	
	//Test for the deafult constructor
	Stack<int> stack_a;								//Use the default constructor to create stack
	Stack<int> stack_b(2);							//Create a constructor accecpts size 2.

	//Assignment operator
	stack_a = stack_b;
	
	//Test the Push() function.
	stack_a.Push(0);
	stack_a.Push(1);
	//stack_a.Push(2);    This is full!!! Out of bounds
	
	cout << "Test the Assignment operator for stack_a and the Push() function." << endl;

	try
	{
		//stack_a.Push(2);							//>=2 will be full!!!Out of bounds
		stack_a.Push(110);
	}
	catch(ArrayException &error)
	{
		cout << error.GetMessage() << endl;			//Error magssage
	}

	//Test the Pop() function for stack_a
	cout << endl << "Test for the Pop() function for the full stack_a" << endl;
	stack_a.Pop();				//Before Pop(), 2 elements left
	stack_a.Pop();				//Before Pop(), 1 element left
	//stack_a.Pop();			 Before Pop(), 0 element left, so after Pop(), out of bounds!!!
	try
	{
		stack_a.Pop();			//Out of bounds
	}
	catch (ArrayException &error)
	{
		cout << error.GetMessage() << endl;			//Error magssage
	}

	//Test the Pop() function for stack_b
	cout << endl << "Test for the Pop() function for the empty stack_b" << endl;
	try
	{
		stack_b.Pop();			//Out of bounds
	}
	catch (ArrayException &error)
	{
		cout << error.GetMessage() << endl;			//Error magssage
	}
	
	//Test the Push() function for the empty stack_b
	stack_b.Push(0);
	stack_b.Push(1);
	//stack_b.Push(2);    This is full!!! Out of bounds

	cout << endl<< "Test the Push() function for the empty stack_b." << endl;

	try
	{
		stack_b.Push(2);							//>=2 will be full!!!Out of bounds
		
	}
	catch (ArrayException &error)
	{
		cout << error.GetMessage() << endl;			//Error magssage
	}
	
	
	//Test the copy constructor
	Stack<int> stack_c(stack_b);
	
	//Test the Pop() function for stack_c
	cout << endl << "Test the copy constructor for stack_c and the Pop() function." << endl;
	try
	{
		stack_c.Pop();								//OK		
		stack_c.Pop();								//OK
		stack_c.Pop();								//Out of bounds
	}
	catch (ArrayException &error)
	{
		cout << error.GetMessage() << endl;			//Error magssage
	}
	
	
}







