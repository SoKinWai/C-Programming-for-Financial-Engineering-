﻿//4.2b - Advanced Templates​
//Exercise 4: Stack Class (composition)
//Create a template class called Stack. It is not a derived class but it uses an Array as data member. You also need a data member for the current index in the array.
//Create the regular constructors, destructor and assignment operator.
//Add a Push() function. It should store the element at the current position in the embedded array. Increment the current position afterwards. 
//There is no need for checking the current index because the array will throw an exception when the stack is full. Make sure the current index is not changed when the Array class threw an exception.
//Add a Pop() function that decrements the current position and then returns the element at that position. 
//Make sure the current index is not changed when the Array class throws an exception.

#ifndef Stack_HPP
#define Stack_HPP
#include "Array.hpp"
#include "ArrayException.hpp"
#include <iostream>
using namespace std;

template<typename T>
class Stack
{
private:
	int m_current;										//A data member for the current index 
	Array<T> d_m;										//Use an Array as data member. 

public:
	Stack();											//Default constructor
	Stack(int s);										//Constructor accepts size
	Stack(const Stack<T>& ss);							//Copy constructor

	virtual ~Stack();									//Destructor


	//Member Operator Overloading
	Stack<T>& operator = (const Stack<T>& source);		//An assignment operator.

	//Add a Push() function
	void Push(const T& push_e);
														
														
	//Add a Pop() function
	const T& Pop();

};

#ifndef Stack_CPP    
#include "Stack.cpp"
#endif

#endif