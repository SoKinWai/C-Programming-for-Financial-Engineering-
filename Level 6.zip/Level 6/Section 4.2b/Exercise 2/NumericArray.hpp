﻿//4.2b - Advanced Templates​
//Exercise 2: Numeric Array (generic inheritance)
//Add a new source and header file for a NumericArray class to your project.
//Create a template class called NumericArray and derive it from the Array class using generic inheritance.
//Since they are not inherited, create proper constructors, destructor and assignment operator and call the base class where appropriate.

#ifndef NumericArray_HPP
#define NumericArray_HPP

#include "Array.hpp"
#include <iostream>
#include <sstream>
using namespace std;

template <typename T>
class NumericArray :public Array<T>
{
private:

public:
	//Constructors
	NumericArray();														//Deafult constructor
	NumericArray(int size);												//Constructor accepts size
	NumericArray(const NumericArray<T>& s);								//Copy constructor
	virtual ~NumericArray();											//Destructor

	//Operator Overloading
	NumericArray<T>& operator = (const NumericArray<T>& source);		// Assignment operator

	//Add the numeric functionalities

	//An operator * to scale the elements of the numeric array by a factor.
	NumericArray<T> operator * ( double factor) const;

	//An operator + to add the elements of two numeric arrays. 
	NumericArray<T> operator + (const NumericArray<T>& a) const;

	//A function to calculate the dot product. 
	T DotProduct(const NumericArray<T>& ar) const;

};

#ifndef NumericArray_CPP     // Must be the same name as in source file #define
#include "NumericArray.cpp"
#endif

#endif 