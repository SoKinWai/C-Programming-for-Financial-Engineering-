﻿//4.2b - Advanced Templates​
//Exercise 2: Numeric Array (generic inheritance)
//Change the main program to test the numeric array.
//Test progeam

#include "Point.hpp"
#include "Array.hpp"					
#include "NumericArray.hpp"				
#include "ArrayException.hpp"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdlib>
using namespace std;

void main()
{
	//Create array with size 2
	NumericArray<double> arr_a(2);
	arr_a[0] = 3;
	arr_a[1] = 5;
	cout << "Check the results for array arr_a with size 2: " << endl;
	cout << arr_a[0] << "," << arr_a[1] << endl << endl;

	//Test the Assignment operator
	NumericArray<double> arr_b;
	arr_b = arr_a;
	cout << "Test the Assignment operator." << endl << "Chcek the results for array arr_b:" << endl;
	cout << arr_b[0] << "," << arr_b[1] << endl << endl;

	//Test the operator * to scale the elements of the numeric array by a factor.
	arr_b = arr_a * 4;
	cout << "Test the operator * to scale the elements of the numeric array by a factor." << endl;
	cout << "Check the results for array arr_b= arr_a x 4: " << endl;
	cout << arr_b[0] << "," << arr_b[1] << endl << endl;

	//Test the operator + to add the elements of two numeric arrays. 
	NumericArray<double> arr_c;
	arr_c = arr_a + arr_b;
	cout << "Test the operator + to add the elements of two numeric arrays." << endl;
	cout << "Check the results for the arr_c= arr_a+ arr_b:" << endl;
	cout << arr_c[0] << "," << arr_c[1] << endl << endl;

	//Test the function to calculate the dot product
	double dot_product;
	dot_product = arr_a.DotProduct(arr_b);
	cout << "Test the function to calculate the dot product." << endl;
	cout << "The dot product for arr_a and arr_b is: " << dot_product << endl << endl;

	//Test for the exception handling
	//Create an array in size 10
	NumericArray<double> arr_d(10);
	
	cout << "Test for the exception handling for opeartor +." << endl;
	
	try
	{
		arr_c = arr_a + arr_d;						//Add two arrays with different sizes
	}

	catch (Different_Size &e)
	{
		cout << e.GetMessage() << endl;			//Print the message for differnt sizes
	}

	catch (...)
	{
		cout << "An unhandled exception has occurred" << endl;
	}

	cout << endl;

	cout << "Test for the exception handling for the function to calculate the dot product." << endl;
	double dot;
	try
	{
		dot= arr_a.DotProduct(arr_d);				//Add two arrays with different sizes
	}

	catch (Different_Size &e)
	{
		cout << e.GetMessage() << endl;			//Print the message for differnt sizes
	}

	catch (...)
	{
		cout << "An unhandled exception has occurred" << endl;
	}

	//Create a numeric array with Point objects
	//NumericArray<Point> p_a;                       
	//NumericArray<Point> p_b(10);
	//Point p_c;
	//p_c=p_a.DotProduct(p_b);          It doesn't work.
	
	
	//What assumptions do you make about the type used as template argument? 
	//I think 'template <typename T>class NumeriArray' can just be used for the classes of numeric data types.


	//Can you create a numeric array with Point objects?
	//I can create a numeric array with Point objects, but DotProduct() function cannot work because the Point * Point operator does not exist.

}