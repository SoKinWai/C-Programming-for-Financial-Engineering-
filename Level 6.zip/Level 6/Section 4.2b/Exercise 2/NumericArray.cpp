﻿//4.2b - Advanced Templates​
//Exercise 2: Numeric Array (generic inheritance)
//Add a new source and header file for a NumericArray class to your project.
//Create a template class called NumericArray and derive it from the Array class using generic inheritance.
//Since they are not inherited, create proper constructors, destructor and assignment operator and call the base class where appropriate.

#ifndef NumericArray_CPP
#define NumericArray_CPP

#include <iostream>
#include "NumericArray.hpp"
#include "Different_Size.hpp"
#include<cmath>
using namespace std;

//Default constructor
template<typename T>
NumericArray<T>::NumericArray() :Array<T>()
{
}

//Constructor accepts size
template<typename T>
NumericArray<T>::NumericArray(int size) :Array<T>(size)
{
}

//Copy constructor
template<typename T>
NumericArray<T>::NumericArray(const NumericArray<T>& s) :Array<T>(s)
{
}

//Destructor
template<typename T>
NumericArray<T>::~NumericArray()
{
}

// Assignment operator
template<typename T>
NumericArray<T>& NumericArray<T>::operator=(const NumericArray<T>& source)
{
	if (this == &source)
	{
		return *this;
	}
	
	//Call the base class
	Array<T>::operator=(source);
	return *this;
}

//An operator * to scale the elements of the numeric array by a factor.
template <typename T>
NumericArray<T> NumericArray<T>:: operator * (double factor) const
{
	//Create a new array
	NumericArray<T> res(*this);

	for (int a = 0;a < res.Size();a++)
	{
		res[a] *= factor;
	}
	
	return res;
}

//An operator + to add the elements of two numeric arrays. 
template <typename T>
NumericArray<T> NumericArray<T>::operator + (const NumericArray<T>& a) const
{
	if (Array<T>::Size() != a.Size())
	{
		throw Different_Size();

	}
	//Create a new array
	NumericArray<T> res(*this);
	
	for (int c = 0;c< res.Size();c++)
	{
		//add the elements of two numeric arrays.
		res[c] += a[c];
	}
	return res;
}

//A function to calculate the dot product.
template <typename T>
T NumericArray<T>::DotProduct(const NumericArray<T>& ar) const
{
	
	if (Array<T>::Size() != ar.Size())
	{
		//If they are not the same size, throw the object
		throw Different_Size();
	}

	//Creat a res value to store the dot product
	T res = 0;
	for (int a = 0;a < Array<T>::Size();a++)
	{
		res += Array<T>::GetElement(a)* ar[a];
	}

	return res;

}


#endif