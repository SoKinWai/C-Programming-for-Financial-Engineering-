﻿//4.2b - Advanced Templates​
//Exercise 2: Numeric Array (generic inheritance)

#include"Different_Size.hpp"
#include<stdlib.h>
#include<iostream>
#include<string>

using namespace std;

Different_Size::Different_Size() :ArrayException()
{
}

Different_Size::~Different_Size() 
{
}

string Different_Size::GetMessage()
{
	stringstream ss;
	ss << "The size of arrays are different." << endl;
	return ss.str();
}