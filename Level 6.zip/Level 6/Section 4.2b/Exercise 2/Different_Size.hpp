﻿//4.2b - Advanced Templates​
//Exercise 2: Numeric Array (generic inheritance)

#ifndef Different_Size_HPP
#define Different_Size_HPP

#include "ArrayException.hpp"
#include <string>
#include <sstream>
#include <iostream>
using namespace std;

class Different_Size : public ArrayException
{
private:
public:
	Different_Size();								//Default constructor

	virtual ~Different_Size();						//Destructor
	
	virtual string GetMessage();					//Getmessage function


};

#endif