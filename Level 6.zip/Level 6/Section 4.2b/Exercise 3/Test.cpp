﻿//4.2b - Advanced Templates​
//Exercise 3: Point Array (concrete inheritance)
//Main program to test the point array.

#include "Point.hpp"
#include "Array.hpp"	
#include "PointArray.hpp"
#include <iostream>
using namespace std;

void main()
{
	// Test constructors

	//Create a Point array with size 2
	PointArray arr_a(2);
	
	//Assign vaules to the elements.
	arr_a[0] = Point(0, 1);
	arr_a[1] = Point(2, 3);				//Or use for loop for the larger integer.

	//Chceck the results
	cout << "Check the results for arr_a:" << endl;
	cout <<"The reseults for arr_a are: "<< arr_a[0] <<","<<arr_a[1]<< endl<<endl;

	//Test for the copy constructor
	PointArray arr_b(arr_a);
	cout << "Test for the copy constructor for arr_b." << endl;
	cout << "The results for arr_b are:" << arr_b[0] << ", " << arr_b[1] << endl << endl;

	//Test for the assignment operator
	PointArray arr_c = arr_a;
	cout << "Test for the assignment operator." << endl;
	cout << "The results for arr_c are:" << arr_c[0] << ", " << arr_c[1] << endl << endl;

	//Test for the Length() function
	cout << "Test for the Length() function." << endl;
	cout << "The length for arr_a: " << arr_a.Length() << endl;
}