﻿//4.2b - Advanced Templates​
//Exercise 3: Point Array (concrete inheritance)


#ifndef ArrayException_HPP
#define ArrayException_HPP
#include <iostream>
#include <sstream>
#include <string>
#include<stdlib.h>
using namespace std;

class ArrayException
{
private:
public:
	ArrayException();															//A default constructor.

	virtual	~ArrayException();													//A destructor. 

																				//Give the ArrayException an abstract GetMessage() function that returns a std::string.
	virtual string GetMessage() = 0;
};

#endif
