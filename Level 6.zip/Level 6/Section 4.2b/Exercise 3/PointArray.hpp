﻿//4.2b - Advanced Templates​
//Exercise 3: Point Array (concrete inheritance)
//Create a PointArray which is derived from Array with the template argument set to Point.
//Create a regular class called PointArray which is derived from Array. The template argument given to Array is Point.
//Since they are not inherited, create proper constructors, destructor and assignment operator and call the base class where appropriate.
//Now we can add functionality specific for a point array. For example add a Length() function that returns the total length between the points in the array.

#ifndef PointArray_HPP
#define PointArray_HPP

#include <sstream>
#include <iostream>
#include "Array.hpp"
#include "Point.hpp"
using namespace std;


class PointArray : public Array<Point>
{
private:

public:
	PointArray();											//Default constructor
	PointArray(int s);										//Constructor with array size
	PointArray(const PointArray& p);						//Copy constructor
	virtual ~PointArray();									//Destructor

	//Member operator overloading
	//Assignment operator
	PointArray& operator=(const PointArray& source);

	//Accessing functions
	//Length() function that returns the total length between the points in the array
	double Length() const;



};

#endif