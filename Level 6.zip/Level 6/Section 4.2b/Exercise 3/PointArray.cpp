﻿//4.2b - Advanced Templates​
//Exercise 3: Point Array (concrete inheritance)
//Create a PointArray which is derived from Array with the template argument set to Point.
//Create a regular class called PointArray which is derived from Array. The template argument given to Array is Point.
//Since they are not inherited, create proper constructors, destructor and assignment operator and call the base class where appropriate.
//Now we can add functionality specific for a point array. For example add a Length() function that returns the total length between the points in the array.

#include "PointArray.hpp"
#include "Point.hpp"
#include <cmath>
#include <iostream>
#include <sstream>
using namespace std;

//Default constructor
PointArray::PointArray() : Array<Point>()
{
}

//Constructor with array size
PointArray::PointArray(int s) : Array<Point>(s)
{
}

//Copy constructor
PointArray::PointArray(const PointArray& p) : Array<Point>(p)
{
}

//Destructor
PointArray::~PointArray()
{
}

//Assignment operator
PointArray& PointArray::operator=(const PointArray& source)
{
	if (this == &source)
	{
		return *this;
	}

	//Call the base class 
	Array<Point>::operator=(source);

	return *this;
}

//Length() function that returns the total length between the points in the array
double PointArray::Length() const
{
	double l = 0.0;

	
		for (int a = 0; a < Array<Point>::Size() - 1;a++)
		{
			l += GetElement(a).Distance(GetElement(a + 1));
		}
	
	return l;


}