﻿//4.2b - Advanced Templates​
//Exercise 5: Layering Exceptions
//The stack exception classes can be implemented in a header file only for simplicity.
//Create a StackException base class and a StackFullException and StackEmptyException derived class.

#ifndef  StackException_HPP
#define  StackException_HPP
#include <sstream>
#include <iostream>
using namespace std;

class  StackException
{
private:
public:
	StackException()									// Default constructor
	{
	}
	
	virtual  ~StackException()							// Destructor
	{
	}
	
	virtual string GetMessage() = 0;

};

class StackFullException : public StackException
{
private:
public:
	// Constructors and destructor
	StackFullException() : StackException()
	{ // Default constructor
	}

	~StackFullException()
	{ // Destructor
	}

	string GetMessage()
	{
		stringstream ss;

		ss<< "The stack is full.";

		return ss.str();
	}
};

class StackEmptyException : public StackException
{
private:
public:
	// Constructors and destructor
	StackEmptyException() : StackException()
	{ // Default constructor
	}

	~StackEmptyException()
	{ // Destructor
	}

	string GetMessage()
	{
		stringstream ss;

		ss<< "The stack is empty.";

		return ss.str();
	}
};

#endif