﻿//4.2b - Advanced Templates​
//Exercise 5: Layering Exceptions
//In the Push() function of stack, place the code in a try ... catch block and catch the array exception.In the catch handler, throw a StackFullException exception.
//In the Pop() function of stack, place the code in a try ... catch block and catch the array exception.In the catch handler, throw a StackEmptyException exception.Also set the current index back to 0.
#ifndef Stack_CPP
#define Stack_CPP
#include "StackException.hpp"	
#include "Stack.hpp"
#include "Array.hpp"
#include <iostream>
using namespace std;
//Default constructor.
template<typename T>
Stack<T>::Stack() :m_current(0),d_m()
{
}

//Constructor accepts size
template<typename T>
Stack<T>::Stack(int s) : m_current(0), d_m(s)
{
}

//Copy constructor
template<typename T>
Stack<T>::Stack(const Stack<T>& ss) : m_current(ss.m_current), d_m(ss.d_m)
{
}

//Destructor
template<typename T>
Stack<T>::~Stack()
{
}

//An assignment operator.
template<typename T>
Stack<T>& Stack<T>:: operator = (const Stack<T>& source)
{
	if (this == &source)
	{
		return *this;
	}

	m_current = source.m_current;
	d_m = source.d_m;
	
	return *this;
}

//Add a Push() function
template<typename T>
void Stack<T>::Push(const T& push_e)
{
	try
	{
		//Store the element at the current position in the embedded array
		d_m[m_current] = push_e;

		//Increment the current position afterwards. 
		m_current++;
	}
	catch (ArrayException& error)
	{
		throw StackFullException();
	};
}

//Add a Pop() function
template<typename T>
const T& Stack<T>::Pop()
{	
	try
	{
		d_m[m_current - 1];
		m_current--;
		return d_m[m_current];
	}
	catch (ArrayException& error)
	{
		throw StackEmptyException();
	};

}

#endif