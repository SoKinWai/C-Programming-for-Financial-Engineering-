﻿//4.2b - Advanced Templates​
//Exercise 5: Layering Exceptions


#include <sstream>
#include <cmath>
#include<stdlib.h>
#include<string>
#include<iostream>
#include "ArrayException.hpp"
using namespace std;

//A default constructor.
ArrayException::ArrayException()
{
}

//A destructor.
ArrayException::~ArrayException()
{
}