﻿//4.2b - Advanced Templates​
//Exercise 5: Layering Exceptions

#ifndef Stack_HPP
#define Stack_HPP
#include "Array.hpp"
#include <iostream>
#include "ArrayException.hpp"			
#include "StackException.hpp"	
using namespace std;

template<typename T>
class Stack
{
private:
	int m_current;										//A data member for the current index 
	Array<T> d_m;										//Use an Array as data member. 

public:
	Stack();											//Default constructor
	Stack(int s);										//Constructor accepts size
	Stack(const Stack<T>& ss);							//Copy constructor

	virtual ~Stack();									//Destructor


	//Member Operator Overloading
	Stack<T>& operator = (const Stack<T>& source);		//An assignment operator.

	//Add a Push() function
	void Push(const T& push_e);
														
														
	//Add a Pop() function
	const T& Pop();

};

#ifndef Stack_CPP    
#include "Stack.cpp"
#endif

#endif