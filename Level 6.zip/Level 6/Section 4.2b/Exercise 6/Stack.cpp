﻿//4.2b - Advanced Templates​
//Exercise 6: Value Template Arguments
//Change the Stack class 
#ifndef Stack_CPP
#define Stack_CPP
#include "StackException.hpp"	
#include "Stack.hpp"
#include "Array.hpp"
#include <iostream>
using namespace std;
//Default constructor.
template<typename T,int size>
Stack<T,size>::Stack() :m_current(0),d_m(size)
{
}

//Copy constructor
template<typename T,int size>
Stack<T,size>::Stack(const Stack<T,size>& ss) : m_current(ss.m_current), d_m(ss.d_m)
{
}

//Destructor
template<typename T,int size>
Stack<T,size>::~Stack()
{
}

//An assignment operator.
template<typename T,int size>
Stack<T, size>& Stack<T, size>:: operator = (const Stack<T, size>& source)
{
	if (this == &source)
	{
		return *this;
	}

	m_current = source.m_current;
	d_m = source.d_m;
	
	return *this;
}

//Add a Push() function
template<typename T, int size>
void Stack<T, size>::Push(const T& push_e)
{
	try
	{
		//Store the element at the current position in the embedded array
		d_m[m_current] = push_e;

		//Increment the current position afterwards. 
		m_current++;
	}
	catch (ArrayException& error)
	{
		throw StackFullException();
	};
}

//Add a Pop() function
template<typename T, int size>
const T& Stack<T, size>::Pop()
{	
	try
	{
		d_m[m_current - 1];
		m_current--;
		return d_m[m_current];
	}
	catch (ArrayException& error)
	{
		throw StackEmptyException();
	};

}

#endif