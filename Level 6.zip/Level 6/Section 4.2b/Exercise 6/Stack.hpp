﻿//4.2b - Advanced Templates​
//Exercise 6: Value Template Arguments
//Change the Stack class 

#ifndef Stack_HPP
#define Stack_HPP
#include "Array.hpp"
#include <iostream>
#include "ArrayException.hpp"			
#include "StackException.hpp"	
using namespace std;

template <typename T, int size>
class Stack
{
private:
	int m_current;										//A data member for the current index 
	Array<T> d_m;										//Use an Array as data member. 

public:
	Stack();											//Default constructor
	Stack(const Stack<T,size>& ss);						//Copy constructor

	virtual ~Stack();									//Destructor


	//Member Operator Overloading
	Stack<T,size>& operator = (const Stack<T,size>& source);		//An assignment operator.

	//Add a Push() function
	void Push(const T& push_e);
														
														
	//Add a Pop() function
	const T& Pop();

};

#ifndef Stack_CPP    
#include "Stack.cpp"
#endif

#endif