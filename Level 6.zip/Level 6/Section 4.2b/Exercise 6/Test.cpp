﻿//4.2b - Advanced Templates​
//Exercise 6: Value Template Arguments
//Change the Stack class 

#include "Stack.hpp"
#include "Array.hpp"
#include <iostream>
using namespace std;

void main()
{
	//Create stack objects to test
	Stack<int, 2> stack_a;
	Stack<int, 2> stack_b;
	Stack<int, 4> stack_c;
	
	//Note that now only stacks with the same size template argument can be copied/assigned.
	//stack_a= stack_c;                Not possible!
	//Stack<int, 4>stack_d(stack_b);   Not possible!

	//Test for the same size for assignment operator and Push() function
	stack_a = stack_b;

	cout << "Test for the same size for assignment operator and Push() function" << endl;
	try
	{
		stack_a.Push(0);
		stack_a.Push(1);
		stack_a.Push(2);					//Out of bound
	}
	catch (StackException &error)
	{
		cout << error.GetMessage() << endl;									//Error Message
	}

	//Test the Pop() function for stack_a

	cout << endl << "Test the Pop() function for stack_a" << endl;
	try
	{
		stack_a.Pop();
		stack_a.Pop();
		stack_a.Pop();					//Out of bound
	}
	catch (StackException &error)
	{
		cout << error.GetMessage() << endl;									//Error Message
	}

	//Test the same size copy constructor and the Pop() function for empty stack
	Stack<int, 4>stack_d(stack_c);

	cout << endl << "Test the same size copy constructor and the Pop() function for empty stack" << endl;
	try
	{
		stack_d.Pop();														//Out of bound
	}
	catch (StackException &error)
	{
		cout << error.GetMessage() << endl;									//Error Message
	}



	cout << endl << "ALL WORKS!" << endl;

}