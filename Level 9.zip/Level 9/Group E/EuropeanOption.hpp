//Level 9: Introductory Computational Finance
//E. Excel Visualization
//European option class is the derived class of the Base class

#ifndef EuropeanOption_HPP
#define EuropeanOption_HPP
#include <string>
#include <iostream>
#include <vector>
#include "Base.hpp"
using namespace std;

class EuropeanOption :public Base
{
private:
	double T;				//Expiry time/maturity. This is a number, e.g. T = 1 means one year.
	double K;				//Strike price
	double sig;				//Volatility
	double r;				//Risk-free interest rate
	double S;				//Current stock price where we wish to price the option
	double b;				//Cost of carry.
	int optType;			// Option name (call, put)

	// Gaussian functions
	double N(double x) const;
	double n(double x) const;
	

	//'Kernel' functions for option calculations(prices and sensitivities)
	double CallPrice();
	double PutPrice();
	double CallDelta();
	double PutDelta();
	double CallGamma();
	double PutGamma();

	// 'Kernel' functions for option calculations(price S)
	double CallPrice(double U) const;
	double PutPrice(double U) const;
	double CallDelta(double U) const;
	double PutDelta(double U) const;

	//Create mesh for put and call prices for increasing S
	vector<double> Mesh_CallPrice(const vector<double>& v) const;
	vector<double> Mesh_PutPrice(const vector<double>& v) const;

public:
	EuropeanOption();																							//Default call option
	EuropeanOption(double t, double k, double si, double R, double s, double B, int opttype);					//Set the options
	EuropeanOption(const EuropeanOption& option2);																//Copy constructor
	virtual ~EuropeanOption();																					// Destructor

	//Assignment Operator
	EuropeanOption& operator = (const EuropeanOption& option2);

	// Functions that calculate option price and sensitivities
	virtual double Price();
	virtual double Price(int U);
	double Delta();
	double Delta(int U);
	double Gamma();

	//Use divided differences to approximate option sensitivities.
	double Delta(double h);
	double Gamma(double h);
	double Delta(int U, double h);

	//This is called put-call parity.
	double PutCallParity();					//Get the option price from put-call parity
	bool CheckParity();						//To check if it conforms the put-call parity

	//Create mesh for prices for increasing S
	vector<double> mesh_price(const vector<double>& v) const;

    //Results from the matrix(option prices or sensitivities).
	virtual void Mesh(int a);				//Option prices for a monotonically increasing range of underlying values of S
	void MeshDelta(int a);					//Delta price for a monotonically increasing range of underlying values of S
	void MeshDelta(int a, double h);		//Approximate option delta of monotonically increasing range of S
	//Option prices, delta and gamma of option matrices.
	virtual void Mesh(const vector<vector<double>>& m);					
	void MeshDelta(const vector<vector<double>>& m);
	void MeshGamma(const vector < vector<double>>& m);

	// Modifier functions
	void toggle();		// Change option type (C/P, P/C)
	//Set the option parameters
	void setparameters(double t, double k, double si, double R, double s, double B, int opttype);
};


#endif
