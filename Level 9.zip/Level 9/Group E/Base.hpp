//Level 9: Introductory Computational Finance
//E. Excel Visualization
//Base class for price calculating functions.

#ifndef Base_HPP
#define Base_HPP
#include <iostream>
#include <vector>
using namespace std;

class Base
{
private:

public:

	//Constructors
	Base();													//Default constructor
	Base(const Base& source);								//Copy constructor
	
	//Destructor
	virtual ~Base();

	//Overloading for common price functions
	virtual double Price() = 0;
	virtual double Price(int U) = 0;

	//Assignment operator
	Base& operator = (const Base& source);

	//Overloading for functions for the matrix(vector to vector)
	virtual void Mesh(int a) = 0;								//The price of vector for different values.
	virtual void Mesh(const vector<vector<double>>& m) = 0;		//Get the price of input.

	
	//Create an array of doubles and it was separated by size j
	vector<double> mesh_array(double startvalue, double endvalue, double j) const
	{
		vector<double> v;
		for (unsigned int a = 0; a < ((endvalue - startvalue) / j + 1);a++)
		{
			v.push_back(startvalue + a * j);
		}

		return v;
	}
																
																
																
	//A function for adding more options during run time. 
	void More(vector<vector<double>>&c, int s, int e);
																
	//This vector is to store the array input(Matrix)
	template <int rows, int columns>
	vector<vector<double>> matrix(double(&array)[rows][columns], int s);
};

//This vector is to store the array input(Matrix)
template<int rows, int columns>
vector < vector<double>>Base::matrix(double(&array)[rows][columns], int s)
{
	//Create a vector for a vector
	//p is the parameter for matrix
	vector<vector<double>> p;

	//A new empty row:r 
	vector<double> r;

	//Use the inner for loop to loop via the matrix
	for (unsigned int a = 0; a < rows; a++)
	{
		for (int b = 0;b < columns;b++)			//Loop via different columns.

			r.push_back(array[a][b]);				//This is for each row.

		p.push_back(r);							//Store a row in the vector

		r.clear();
	}

	return p;
}

#endif