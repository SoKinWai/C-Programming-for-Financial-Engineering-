//Level 9: Introductory Computational Finance
//E. Excel Visualization
//Test program.

#include "Base.hpp"
#include "EuropeanOption.hpp"
#include <vector>
#include <iomanip>	
#include <iostream> 
#include <cmath>
#include <string>
#include <list>
#include "UtilitiesDJD/ExcelDriver/ExcelDriverLite.hpp"
#include "UtilitiesDJD/ExcelDriver/Utilities.hpp"
using namespace std;

void main()
{

	//Batch 1
	/* double T = 0.25;				//Expiry date
	double K = 65;					//Strike price
	double sig = 0.30;				//Volatility
	double r = 0.08;				//Interest rate
	double S = 60;					//Current stock price
	double b = r;					//Cost of carry
	int optType = 1; */				//Option type (Call:1, Put:-1) 

	//Batch 2
	/* double T = 1.0;				//Expiry date
	double K = 100;					//Strike price
	double sig = 0.2;				//Volatility
	double r = 0.0;				    //Interest rate
	double S = 100;					//Current stock price
	double b = r;					//Cost of carry
	int optType = 1;		*/		//Option type (Call:1, Put:-1)
	
	
	//Batch 3
	/*double T = 1.0;				//Expiry date
	double K = 10;					//Strike price
	double sig = 0.50;				//Volatility
	double r = 0.12;				    //Interest rate
	double S = 5;					//Current stock price
	double b = r;					//Cost of carry
	int optType = 1;	*/			//Option type (Call:1, Put:-1)
	
	//Batch 4
	double T = 30.0;				//Expiry date
	double K = 100;					//Strike price
	double sig = 0.30;				//Volatility
	double r = 0.08;				    //Interest rate
	double S = 100;					//Current stock price
	double b = r;					//Cost of carry
	int optType = 1;				//Option type (Call:1, Put:-1)
	
	
	//Create an object of EuropeanOption
	EuropeanOption object(T, K, sig, r, S, b, optType);

	//Set the beginning S=10 and the ending S=50
	vector<double> M = object.mesh_array(10, 50, 1);

	
	auto Call = object.mesh_price(M);				//For Call option values
 
	object.toggle();								// Toggle the option type

	auto Put = object.mesh_price(M);				//For Put option values


	
	
	list<vector<double>> c{ Call, Put };

	
	list<string> l{ "Call value for Batch 4", "Put value for Batch 4" };


	ExcelDriver xl; xl.MakeVisible(true);
	xl.CreateChart(M, l, c, "Underlying value of inceasing S:", "S:", "Option Price:");
	




}