//Level 9: Introductory Computational Finance
//Groups A&B: Exact Pricing Methods
//B. Perpetual American Options
//Perpetual American Options option class is the derived class of the Base class

#ifndef PerpetualAmericanOptions_HPP
#define PerpetualAmericanOptions_HPP
#include <string>
#include <iostream>
#include <vector>
#include "Base.hpp"
using namespace std;

class PerpetualAmericanOptions :public Base
{
private:
	double K;				//Strike price
	double sig;				//Volatility
	double r;				//Risk-free interest rate
	double S;				//Current stock price where we wish to price the option
	double b;				//Cost of carry.
	int optType;			// Option name (call, put)

	//'Kernel' functions for option calculations
	double CallPrice();
	double PutPrice();

	// 'Kernel' functions for option calculations(price S)
	double CallPrice(double U) const;
	double PutPrice(double U) const;

public:
	//Constructors
	PerpetualAmericanOptions();
	PerpetualAmericanOptions(double k, double si, double R, double s, double B, int opttype);
	PerpetualAmericanOptions(const PerpetualAmericanOptions& s);		//Copy constructor

	//Destructor
	virtual ~PerpetualAmericanOptions();	


	//Assignment Operator
	PerpetualAmericanOptions& operator=(const PerpetualAmericanOptions& s);

	// Functions that calculate option price and sensitivities
	virtual double Price();
	virtual double Price(int U);

	//Results from the matrix(option prices or sensitivities).
	virtual void Mesh(int a);				//Option prices for a monotonically increasing range of underlying values of S
	
	//Option prices of option matrix.
	virtual void Mesh(const vector<vector<double>>& m);

	// Modifier functions
	void toggle();		// Change option type (C/P, P/C)
	
	//Set the option parameters
	void setparameters(double k, double si, double R, double s, double B, int opttype);

};

#endif

