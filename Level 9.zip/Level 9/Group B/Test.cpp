//Level 9: Introductory Computational Finance
//Groups A&B: Exact Pricing Methods
//B. Perpetual American Options
//Test program

#include <iostream>
#include<vector>
#include<iomanip>
#include "Base.hpp"
#include "PerpetualAmericanOptions.hpp"
using namespace std;


void main()
{
	//Question a and b
	
	double K = 100;				//Strike price
	double sig = 0.1;			//Volatility
	double r = 0.1;				//Interest rate
	double S = 110;				//Current stock price
	double b = 0.02;			//Cost of carry
	int optType = 1;			//Option type (Call:1, Put:-1)

	//Use pointer
	PerpetualAmericanOptions *object=new PerpetualAmericanOptions(K, sig, r, S, b, optType);

	cout << "Test for question a and b:" << endl;
	
	//Calculate the price of the call and put because optType = 1
	cout << "Call:" << object->Price() << endl;
	object->toggle();		// Toggle the option type
	cout << "Put: " << object->Price() << endl << endl;

	//Question c
	//The beginning price is 10
	S = 10;

	object = new PerpetualAmericanOptions(K, sig, r, S, b, optType);

	//The range a is 25
	int a = 25;

	cout << "Test for question c:" << endl;
	//Compute call and put option price for a monotonically increasing range of underlying values of S
	
	//Call option prices
	cout << "For the Call option price:" << endl;
	object->Mesh(a);	
	
	cout << endl << "For the Put option price:" << endl;
	object->toggle();	// Toggle the option type
	
	//Put option prices
	object->Mesh(a);
	cout << endl;
	delete object;

	//Question d
	//Incorporate this into your above matrix pricer code

	//Array size s is 6. 
	const int s = 6;

	//K sigma r S b optType(-1 is put, 1 is call)
	double p[][s] =
	{
		
	//Batch 1
	{100,0.1,0.1,0.02,110,1/*or use -1*/ },
		
	//Batch 2
	{ 100, 0.36, 0.1, 0, 105, 1 /*or use -1*/ },

	//Batch 3
	{ 65, 0.3, 0.08, 0.08, 60, -1/*or use 1*/ },

	//Batch 4
	{ 100, 0.2, 0, 0,100,  1/*or use -1*/ },

	//Batch 5
	{ 100, 0.5, 0.12, 0.12, 5, -1/*or use 1*/ }

	//Batch......

	};

	object = new PerpetualAmericanOptions;

	//This vector is to store the array input
	vector<vector<double>> Option_Matrix = object->matrix(p, s);

	cout << "Test question d." << endl;

	//Adding more options during run time.
	//int e = 1;
	//object->More(Option_Matrix, s, e);

	//To show the mesh option prices.
	object->Mesh(Option_Matrix);
	delete object;

}