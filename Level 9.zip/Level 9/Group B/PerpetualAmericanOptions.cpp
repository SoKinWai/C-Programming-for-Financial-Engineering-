//Level 9: Introductory Computational Finance
//Groups A&B: Exact Pricing Methods
//B. Perpetual American Options
//Perpetual American Options option class is the derived class of the Base class

#include <cmath>
#include <iostream>
#include <vector>
#include "PerpetualAmericanOptions.hpp"
using namespace std;

double PerpetualAmericanOptions::CallPrice()
{
	// Dividend q = r - b

	double sig2 = sig * sig;
	double fac = b / sig2 - 0.5; fac *= fac;
	double y1 = 0.5 - b / sig2 + sqrt(fac + 2.0*r / sig2);


	if (1.0 == y1)
		return S;

	double fac2 = ((y1 - 1.0)*S) / (y1 * K);
	double c = K * pow(fac2, y1) / (y1 - 1.0);

	return c;
}

double PerpetualAmericanOptions::PutPrice()
{
	double sig2 = sig * sig;
	double fac = b / sig2 - 0.5; fac *= fac;
	double y2 = 0.5 - b / sig2 - sqrt(fac + 2.0*r / sig2);

	if (0.0 == y2)
		return S;

	double fac2 = ((y2 - 1.0)*S) / (y2 * K);
	double p = K * pow(fac2, y2) / (1.0 - y2);

	return p;
}

double PerpetualAmericanOptions::CallPrice(double U) const
{
	// Dividend q = r - b

	double sig2 = sig * sig;
	double fac = b / sig2 - 0.5; fac *= fac;
	double y1 = 0.5 - b / sig2 + sqrt(fac + 2.0*r / sig2);


	if (1.0 == y1)
		return U;

	double fac2 = ((y1 - 1.0)*U) / (y1 * K);
	double c = K * pow(fac2, y1) / (y1 - 1.0);

	return c;

}

double PerpetualAmericanOptions::PutPrice(double U) const
{
	double sig2 = sig * sig;
	double fac = b / sig2 - 0.5; fac *= fac;
	double y2 = 0.5 - b / sig2 - sqrt(fac + 2.0*r / sig2);

	if (0.0 == y2)
		return U;

	double fac2 = ((y2 - 1.0)*U) / (y2 * K);
	double p = K * pow(fac2, y2) / (1.0 - y2);

	return p;
}

//Default constructor
PerpetualAmericanOptions::PerpetualAmericanOptions() :Base()
{
	K = 100;
	sig = 0.1;
	r = 0.1;
	S = 110;
	b = r;
	optType = 1;
}

//Set the options
PerpetualAmericanOptions::PerpetualAmericanOptions(double k, double si, double R, double s, double B, int opttype) :Base()
{
	K = k;
	sig = si;
	r = R;
	S = s;
	b = B;
	optType = opttype;
}


//Copy constructor
PerpetualAmericanOptions::PerpetualAmericanOptions(const PerpetualAmericanOptions& s) :Base()
{
	K = s.K;
	sig = s.sig;
	r = s.r;
	S = s.S;
	b = s.b;
	optType = s.optType;
}

//Destructor
PerpetualAmericanOptions::~PerpetualAmericanOptions()
{
}

//Assignment Operator
PerpetualAmericanOptions& PerpetualAmericanOptions::operator=(const PerpetualAmericanOptions& s)
{
	if (this == &s)
	{
		return *this;
	}

	Base::operator=(s);

	K = s.K;
	sig = s.sig;
	r = s.r;
	S = s.S;
	b = s.b;
	optType = s.optType;

	return *this;
}

// Functions that calculate option price and sensitivities

double PerpetualAmericanOptions::Price()
{
	if (optType == 1)
	{
		return CallPrice();
	}

	else
	{
		return PutPrice();
	}
}

double PerpetualAmericanOptions::Price(int U)
{
	if (optType == 1)
	{
		return CallPrice(U);
	}

	else
	{
		return PutPrice(U);
	}


}

//Results from the matrix(option prices or sensitivities).
//Option prices for a monotonically increasing range of underlying values of S
void PerpetualAmericanOptions::Mesh(int a)
{
	//A vector to store the price
	vector<double> MeshPrice;

	//Use for loop to get the value S with the range a
	for (int b = int(S);b <= S + a;b++)
	{
		MeshPrice.push_back(Price(b));
	}

	//Use for loop to show the Underlying value of S and option price.
	for (unsigned int c = 0;c < MeshPrice.size();c++)
	{
		cout << "Underlying value of S:" << S + c << " ,     Option Price:" << MeshPrice[c] << endl;
	}
}



//Option prices  option matrix.
void PerpetualAmericanOptions::Mesh(const vector<vector<double>>& m)
{
	//A vector to store the price
	vector<double> MeshPrice;

	for (unsigned int a = 0;a < m.size();a++)
	{

		K = m[a][0];
		sig = m[a][1];
		r = m[a][2];
		b = m[a][3];
		S = m[a][4];
		optType = (int)m[a][5];

		MeshPrice.push_back(this->Price());
	}

	//Use for loop to show option and price
	for (unsigned int c = 0;c < MeshPrice.size();c++)
	{
		cout << "Option and Price:" << c + 1 << " and " << MeshPrice[c] << endl;
	}
}

// Modifier functions
void PerpetualAmericanOptions::toggle()
{ // Change option type (C/P, P/C)

	if (optType == 1)
		optType = -1;
	else
		optType = 1;
}

//Set the option parameters
void PerpetualAmericanOptions::setparameters(double k, double si, double R, double s, double B, int opttype)
{
	
	K = k;
	sig = si;
	r = R;
	S = s;
	b = B;
	optType = opttype;
}

