//Level 9: Introductory Computational Finance
//Groups A&B: Exact Pricing Methods
//A. Exact Solutions of One-Factor Plain Options
//European option class is the derived class of the Base class

#include "EuropeanOption.hpp"
#include <cmath>
#include <iostream>
#include <vector>
// In general, we would use similar functions in Boost::Math Toolkit
#include <boost/math/distributions.hpp>// For non-member functions of distributions
#include <boost/math/distributions/normal.hpp>
using namespace boost::math;
using namespace std;

//Gaussian functions
double EuropeanOption::N(double x) const
{
	normal_distribution<> myNormal(0.0, 1.0);

	return cdf(myNormal, x);
}

double EuropeanOption::n(double x) const
{
	normal_distribution<> myNormal(0.0, 1.0);

	return pdf(myNormal, x);
}

//'Kernel' functions for option calculations(prices and sensitivities)
double EuropeanOption::CallPrice()
{
	double tmp = sig * sqrt(T);

	double d1 = (log(S / K) + (b + (sig*sig)*0.5) * T) / tmp;
	double d2 = d1 - tmp;


	return (S * exp((b - r)*T) * N(d1)) - (K * exp(-r * T)* N(d2));
}

double EuropeanOption::PutPrice()
{
	double tmp = sig * sqrt(T);
	double d1 = (log(S / K) + (b + (sig*sig)*0.5) * T) / tmp;
	double d2 = d1 - tmp;

	return (K * exp(-r * T)* N(-d2)) - (S * exp((b - r)*T) * N(-d1));

}

double EuropeanOption::CallDelta()
{
	double tmp = sig * sqrt(T);

	double d1 = (log(S / K) + (b + (sig*sig)*0.5) * T) / tmp;


	return exp((b - r)*T) * N(d1);
}

double EuropeanOption::PutDelta()
{
	double tmp = sig * sqrt(T);

	double d1 = (log(S / K) + (b + (sig*sig)*0.5) * T) / tmp;

	return exp((b - r)*T) * (N(d1) - 1.0);


}

double EuropeanOption::CallGamma()
{
	double tmp = sig * sqrt(T);

	double d1 = (log(S / K) + (b + (sig*sig)*0.5) * T) / tmp;
	double d2 = d1 - tmp;

	return (n(d1) * exp((b - r)*T)) / (S * tmp);
}

double EuropeanOption::PutGamma()
{
	return CallGamma();
}

// 'Kernel' functions for option calculations(price S)
// Kernel Functions (Haug)
double EuropeanOption::CallPrice(double U) const
{

	double tmp = sig * sqrt(T);

	double d1 = (log(U / K) + (b + (sig*sig)*0.5) * T) / tmp;
	double d2 = d1 - tmp;


	return (U * exp((b - r)*T) * N(d1)) - (K * exp(-r * T)* N(d2));

}

double EuropeanOption::PutPrice(double U) const
{

	double tmp = sig * sqrt(T);
	double d1 = (log(U / K) + (b + (sig*sig)*0.5) * T) / tmp;
	double d2 = d1 - tmp;

	return (K * exp(-r * T)* N(-d2)) - (U * exp((b - r)*T) * N(-d1));

}

double EuropeanOption::CallDelta(double U) const
{
	double tmp = sig * sqrt(T);

	double d1 = (log(U / K) + (b + (sig*sig)*0.5) * T) / tmp;


	return exp((b - r)*T) * N(d1);
}

double EuropeanOption::PutDelta(double U) const
{
	double tmp = sig * sqrt(T);

	double d1 = (log(U / K) + (b + (sig*sig)*0.5) * T) / tmp;

	return exp((b - r)*T) * (N(d1) - 1.0);
}

/* Cost of carry factor b must be included in formulae depending on the
derivative type. These are used in the generalised Black-Scholes formula.
If r is the risk-free interest and q is the continuous dividend yield then
the cost-of-carry b per derivative type is:

a) Black-Scholes (1973) stock option model: b = r
b) b = r - q Merton (1973) stock option model with continuous dividend yield
c) b = 0 Black (1976) futures option model
d) b = r - rf Garman and Kohlhagen (1983) currency option model, where rf is the
'foreign' interest rate
*/

//Default call option
EuropeanOption::EuropeanOption():Base()
{
	T = 0.25;
	K = 65.0; 
	sig = 0.3; 
	r = 0.08;
	S = 60; 
	b = r;
	optType = 1;
}

//Set the options
EuropeanOption::EuropeanOption(double t, double k, double si, double R, double s, double B, int opttype):Base()
{
	T = t;
	K = k;
	sig = si;
	r = R;
	S = s;
	b = B;
	optType = opttype;
}

//Copy constructor
EuropeanOption::EuropeanOption(const EuropeanOption& option2) :Base()
{
	T = option2.T;
	K = option2.K;
	sig = option2.sig;
	r = option2.r;
	S = option2.S;
	b = option2.b;
	optType = option2.optType;
}

//Destructor
EuropeanOption::~EuropeanOption() 
{

}

//Assignment Operator
EuropeanOption& EuropeanOption::operator = (const EuropeanOption& option2)
{
	if (this == &option2) return *this;

	Base::operator=(option2);
	
	T = option2.T;
	K = option2.K;
	sig = option2.sig;
	r = option2.r;
	S = option2.S;
	b = option2.b;
	optType = option2.optType;
	
	return *this;
}

// Functions that calculate option price and sensitivities
double EuropeanOption::Price()
{
	if (optType == 1)
	{
		return CallPrice();
	}

	else
	{
		return PutPrice();
	}

}

double EuropeanOption::Price(int U)
{
	if (optType == 1)
	{
		return CallPrice(U);
	}

	else
	{
		return PutPrice(U);
	}
}

double EuropeanOption::Delta()
{
	if (optType == 1)
	{
		return CallDelta();
	}

	else
	{
		return PutDelta();
	}
}

double EuropeanOption::Delta(int U)
{
	if (optType == 1)
	{
		return CallDelta(U);
	}

	else
	{
		return PutDelta(U);
	}
}

double EuropeanOption::Gamma()
{
	if (optType == 1)
	{
		return CallGamma();
	}

	else
	{
		return PutGamma();
	}
}

//Use divided differences to approximate option sensitivities.
double EuropeanOption::Delta(double h)
{
	if (optType == 1)
	{
		return (CallPrice(S + h) - CallPrice(S - h)) / (2.0*h);
	}
	else
	{
		return (PutPrice(S + h) - PutPrice(S - h)) / (2.0*h);
	}

}

double EuropeanOption::Gamma(double h)
{
	if (optType == 1)
	{
		return (CallPrice(S + h) - CallPrice(S) * 2 + CallPrice(S - h)) / (h*h);
	}
	else
	{
		return  (PutPrice(S + h) - PutPrice(S) * 2 + PutPrice(S - h)) / (h*h);
	}
}

double EuropeanOption::Delta(int U, double h)
{
	if (optType == 1)
	{
		return (CallPrice(U + h) - CallPrice(U - h)) / (2.0*h);
	}
	else
	{
		return (PutPrice(U + h) - PutPrice(U - h)) / (2.0*h);
	}
}

//This is called put-call parity.
double EuropeanOption::PutCallParity()					//Get the option price from put-call parity
{
	if (optType == 1)
	{
		return CallPrice() + K * exp(-r * T) - S;
	}
	else
	{
		return PutPrice() - K * exp(-r * T) + S;
	}
}

//To check if it conforms the put-call parity
bool EuropeanOption::CheckParity()
{
	return abs(S + PutPrice() - K * exp(-r * T) - CallPrice()) < 1e-10;
}

//Results from the matrix(option prices or sensitivities).
//Option prices for a monotonically increasing range of underlying values of S
void EuropeanOption::Mesh(int a)
{
	//A vector to store the price
	vector<double> MeshPrice;

	//Use for loop to get the value S with the range a
	for (int b = int(S);b <= S + a;b++)
	{
		MeshPrice.push_back(Price(b));
	}
	
	//Use for loop to show the Underlying value of S and option price.
	for (unsigned int c = 0;c < MeshPrice.size();c++)
	{
		cout << "Underlying value of S:" << S + c << " ,     Option Price:" << MeshPrice[c] << endl;
	}
}

//Delta price for a monotonically increasing range of underlying values of S
void EuropeanOption::MeshDelta(int a)
{
	//A vector to store the price
	vector<double> meshdelta;

	//Use for loop to get the value S with the range a
	for (int b = int(S);b <= S + a;b++)
	{
		meshdelta.push_back(Delta(b));
	}

	//Use for loop to show the Underlying value of S and option delta.
	for (unsigned int c = 0;c < meshdelta.size();c++)
	{
		cout << "Underlying value of S:" << S + c << " ,     Option Delta:" << meshdelta[c] << endl;
	}

}

//Approximate option delta of monotonically increasing range of S
void EuropeanOption::MeshDelta(int a, double h)
{
	//A vector to store the price
	vector<double> meshdelta;

	//Use for loop to get the value S with the range a
	for (int b = int(S);b <= S + a;b++)
	{
		meshdelta.push_back(Delta(b, h));
	}

	//Use for loop to show the Underlying value of S and option delta.
	for (unsigned int c = 0;c < meshdelta.size();c++)
	{
		cout << "Underlying value of S:" << S + c << " ,     Approximation of Option Delta:" << meshdelta[c] << endl;
	}

}

//Option prices, delta and gamma of option matrices.

void EuropeanOption::Mesh(const vector<vector<double>>& m)
{
	//A vector to store the price
	vector<double> MeshPrice;

	for (unsigned int a = 0;a < m.size();a++)
	{
		T = m[a][0];
		K = m[a][1];
		sig = m[a][2];
		r = m[a][3];
		S = m[a][4];
		b = m[a][5];
		optType = (int)m[a][6];

		MeshPrice.push_back(this->Price());
	}

	//Use for loop to show option and price
	for (unsigned int c = 0;c < MeshPrice.size();c++)
	{
		cout << "Option and Price:" << c + 1 << " and " << MeshPrice[c] << endl;
	}
}

void EuropeanOption::MeshDelta(const vector<vector<double>>& m)
{
	//A vector to store the price
	vector<double> meshdelta;

	for (unsigned int a = 0;a < m.size();a++)
	{
		T = m[a][0];
		K = m[a][1];
		sig = m[a][2];
		r = m[a][3];
		S = m[a][4];
		b = m[a][5];
		optType = (int)m[a][6];

		meshdelta.push_back(Delta());
	}

	//Use for loop to show option and delta
	for (unsigned int c = 0;c < meshdelta.size();c++)
	{
		cout << "Option and Delta:" << c + 1 << " and " << meshdelta[c] << endl;
	}

}

void EuropeanOption::MeshGamma(const vector < vector<double>>& m)
{
	//A vector to store the price
	vector<double> meshgamma;

	for (unsigned int a = 0;a < m.size();a++)
	{
		T = m[a][0];
		K = m[a][1];
		sig = m[a][2];
		r = m[a][3];
		S = m[a][4];
		b = m[a][5];
		optType = (int)m[a][6];

		meshgamma.push_back(Gamma());
	}

	// Use for loop to show option and gamma
	for (unsigned int c = 0;c < meshgamma.size();c++)
	{
		cout << "Option and Gamma:" << c + 1 << " and " << meshgamma[c] << endl;
	}
}

// Modifier functions
void EuropeanOption::toggle()
{ // Change option type (C/P, P/C)

	if (optType == 1)
		optType = -1;
	else
		optType = 1;
}

//Set the option parameters
void EuropeanOption::setparameters(double t, double k, double si, double R, double s, double B, int opttype)
{
	T = t;
	K = k;
	sig = si;
	r = R;
	S = s;
	b = B;
	optType = opttype;
}
