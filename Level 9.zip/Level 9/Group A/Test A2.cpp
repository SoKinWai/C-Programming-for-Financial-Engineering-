//Level 9: Introductory Computational Finance
//Groups A&B: Exact Pricing Methods
//A. Exact Solutions of One-Factor Plain Options
//A2��Option Sensitivities, aka the Greeks
//Test Program

#include <iostream>
#include<vector>
#include<iomanip>
#include "Base.hpp"
#include "EuropeanOption.hpp"
using namespace std;

void main()
{
	//A2��Option Sensitivities, aka the Greeks
	cout << "A2��Option Sensitivities, aka the Greeks" << endl;

	//Question a
	double T = 0.5;				//Expiry date
	double K = 100;					//Strike price
	double sig = 0.36;				//Volatility
	double r = 0.1;				//Interest rate
	double S = 105;					//Current stock price
	double b = 0;					//Cost of carry
	int optType = 1;				//Option type (Call:1, Put:-1)

	EuropeanOption *object = new EuropeanOption(T, K, sig, r, S, b, optType);

	cout << "Test for question a:" << endl;

	//Calculate Call delta
	cout << "Call delta: " << object->Delta() << endl;

	//Calculate Call gamma
	cout << "Call gamma:" << object->Gamma() << endl;
	object->toggle();	// Toggle the option type
	
	//Calculate Put delta
	cout << "Put delta:" << object->Delta() << endl;

	//Calculate Put gamma
	cout << "Put gamma:" << object->Gamma() << endl << endl;

	//Question b
	//Use the code in part a to compute call delta price for a monotonically increasing range of underlying values of S, S=105
	
	//Set the range x=20
	int x = 20;
	cout << "Test for question b" << endl;

	object->MeshDelta(x);

	cout << endl;
	delete object;

	//Question c
	
	//I create array size k is 7. 
	const int k = 7;

	//T K sigma r S b optType(-1 is put, 1 is call)
	//I use Batch 1 to 4 from the question gave me and I add batch 5 into it.
	double q[][k] =
	{
		//Batch 1
		{ 0.25, 65, 0.3, 0.08, 60, 0.08, 1 /*or use -1*/ },

		//Batch 2
		{ 1, 100, 0.2, 0, 100, 0, 1/*or use -1*/ },

		//Batch 3
		{ 1, 10, 0.5, 0.12, 5, 0.12, -1/*or use 1*/ },

		//Batch 4
		{ 30, 100, 0.3, 0.08, 100, 0.08, -1/*or use 1*/ },

	//Batch 5
	{31,101,0.4,0.09,101,0.09,1/*or use -1*/}
	
	//Batch......

	};

	object = new EuropeanOption;

	//This vector is to store the array input
	vector<vector<double>> z = object->matrix(q, k);
	
	cout << "Test for question c:" << endl;

	//Incorporate this into above matrix pricer code, so I can input a matrix of option parameters and receive a matrix of either Delta or Gamma as the result.
	object->MeshDelta(z);
	object->MeshGamma(z);
	cout << endl;
	delete object;

	//Question d
	//Let's set h=0.000001
	double h = 0.000001;

	object = new EuropeanOption(T, K, sig, r, S, b, optType);

	cout << "Test for question d:" << endl;

	//Approixmation for call delta
	cout << "Approixmation for call delta:" << object->Delta(h) << endl;

	//Approixmation for call gamma
	cout << "Approixmation for call gamma:" << object->Gamma(h) << endl;

	//Toggle the option type
	object->toggle();

	//Approixmation for put delta
	cout << "Approixmation for put delta:" << object->Delta(h) << endl;

	//Approixmation for put gamma
	cout << "Approixmation for put gamma:" << object->Gamma(h) << endl << endl;

	//Use the data from question a, so range is x=20 and S is 105. 
	//Show the approximation of price by using matrix.
	cout << "Test with S is 105 and range is 20: " << endl;
	object->MeshDelta(x, h);
	delete object;

	/*
	
	//Question d
	//Let's set h= 0.000002, h= 0.000003, h= 0.000004, h= 0.000005, h= 0.000006, h= 0.000007 and h= 0.000008����
	double h = 0.000001;

	object = new EuropeanOption(T, K, sig, r, S, b, optType);

	cout << "Test for question d:" << endl;

	//Approixmation for call delta
	cout << "Approixmation for call delta:" << object->Delta(h) << endl;

	//Approixmation for call gamma
	cout << "Approixmation for call gamma:" << object->Gamma(h) << endl;

	//Toggle the option type
	object->toggle();

	//Approixmation for put delta
	cout << "Approixmation for put delta:" << object->Delta(h) << endl;

	//Approixmation for put gamma
	cout << "Approixmation for put gamma:" << object->Gamma(h) << endl << endl;

	//Use the data from question a, so range is x=20 and S is 105. 
	//Show the approximation of price by using matrix.
	cout << "Test with S is 105 and range is 20: " << endl;
	object->MeshDelta(x, h);
	delete object;
	
	
	
	
	
	
	*/

}