//Level 9: Introductory Computational Finance
//Groups A&B: Exact Pricing Methods
//A. Exact Solutions of One-Factor Plain Options
//A1
//Test Program

#include <iostream>
#include<vector>
#include<iomanip>
#include "Base.hpp"
#include "EuropeanOption.hpp"
using namespace std;

void main()
{
	//Question a and b
	//Batch 1
	double T = 0.25;				//Expiry date
	double K = 65;					//Strike price
	double sig = 0.30;				//Volatility
	double r = 0.08;				//Interest rate
	double S = 60;					//Current stock price
	double b = r;					//Cost of carry
	int optType = 1;				//Option type (Call:1, Put:-1)

	//Create an object of EuropeanOption
	//Use the pointer
	EuropeanOption *object=new EuropeanOption(T, K, sig, r, S, b, optType);
	
	cout << "Test for question a and b:" << endl;
	cout << "Batch 1:" << endl;

	//Calculate the price of the call and put because optType = 1
	cout << "Call: " << object->Price() << endl;
	object->toggle();	// Toggle the option type
	cout << "Put : " << object->Price() << endl;
	
	//Calculate the option price by using put call parity.
	cout << "Option price by using put call parity: " << object->PutCallParity() << endl;
	
	
	//To check if it conforms the put-call parity
	cout << "To check if it conforms the put call parity (1 is hold, 0 is not hold): " << object->CheckParity() << endl;
	delete object;
	cout << endl;

	//Batch 2
	T = 1.0;				//Expiry date
	K = 100;				//Strike price
	sig = 0.2;				//Volatility
	r = 0.0;				//Interest rate
	S =100;					//Current stock price
	b = r;					//Cost of carry
	optType = 1;			//Option type (Call:1, Put:-1)

	//Create an object of EuropeanOption
	//Use Pointer
	object=new EuropeanOption(T, K, sig, r, S, b, optType);

	cout << "Batch 2:" << endl;

	//Calculate the price of the call and put because optType = 1
	cout << "Call: " << object->Price() << endl;
	object->toggle();	// Toggle the option type
	cout << "Put : " << object->Price() << endl;

	//Calculate the option price by using put call parity.
	cout << "Option price by using put call parity: " << object->PutCallParity() << endl;

	//To check if it conforms the put-call parity
	cout << "To check if it conforms the put call parity (1 is hold, 0 is not hold): " << object->CheckParity() << endl;
	
	delete object;
	cout << endl;


	//Batch 3
	T = 1.0;				//Expiry date
	K = 10;					//Strike price
	sig = 0.50;				//Volatility
	r = 0.12;				//Interest rate
	S = 5;					//Current stock price
	b = r;					//Cost of carry
	optType = 1;			//Option type (Call:1, Put:-1)

	//Create an object of EuropeanOption
	EuropeanOption object_a (T, K, sig, r, S, b, optType);

	cout << "Batch 3:" << endl;

	//Calculate the price of the call and put because optType = 1
	cout << "Call: " << object_a.Price() << endl;
	object_a.toggle();	// Toggle the option type
	cout << "Put : " << object_a.Price() << endl;

	//Calculate the option price by using put call parity.
	cout << "Option price by using put call parity: " << object_a.PutCallParity() << endl;

	//To check if it conforms the put-call parity
	cout << "To check if it conforms the put call parity (1 is hold, 0 is not hold): " << object_a.CheckParity() << endl;
	
	cout << endl;

	//Batch 4
	T = 30.0;				//Expiry date
	K = 100;				//Strike price
	sig = 0.30;				//Volatility
	r = 0.08;				//Interest rate
	S = 100;				//Current stock price
	b = r;					//Cost of carry
	optType = 1;			//Option type (Call:1, Put:-1)

	//Create an object of EuropeanOption
	object_a.setparameters(T, K, sig, r, S, b, optType);

	cout << "Batch 4:" << endl;

	//Calculate the price of the call and put since optType = 1
	cout << "Call: " << object_a.Price() << endl;
	object_a.toggle();	// Toggle the option type
	cout << "Put : " << object_a.Price() << endl;

	//Calculate the option price by using put call parity.
	cout << "Option price by using put call parity: " << object_a.PutCallParity() << endl;

	//To check if it conforms the put-call parity
	cout << "To check if it conforms the put call parity (1 is hold, 0 is not hold): " << object_a.CheckParity() << endl;
	cout << endl;

	//Question c
	//The beginning price is 10.
	S = 10;
	
	object = new EuropeanOption(T, K, sig, r, S, b, optType);

	//The range a is 25
	int a = 25;
	
	cout << "Test for question c:" << endl;
	
	//Compute option prices for a monotonically increasing range of underlying values of S=10
	object->Mesh(a);
	cout << endl;
	delete object;

	//Question d

	//Array size s is 7. 
	const int s = 7;

	//T K sigma r S b optType(-1 is put, 1 is call)
	double p[][s] =
	{
	//Batch 1
	{0.25, 65, 0.3, 0.08, 60, 0.08, 1 /*or use -1*/},		
	
	//Batch 2
	{1, 100, 0.2, 0, 100, 0, 1/*or use -1*/},	
	
	//Batch 3
	{1, 10, 0.5, 0.12, 5, 0.12, -1/*or use 1*/},		
	
	//Batch 4
	{30, 100, 0.3, 0.08, 100, 0.08, -1/*or use 1*/}

	//Batch......
																	
	};

	object = new EuropeanOption;

	//This vector is to store the array input
	vector<vector<double>> Option_Matrix = object->matrix(p, s);

	cout << "Test question d." << endl;
	
	//Adding more options during run time.
	int e = 3;
	object->More(Option_Matrix, s, e);

	//To show the mesh option prices.
	object->Mesh(Option_Matrix);
	delete object;


}