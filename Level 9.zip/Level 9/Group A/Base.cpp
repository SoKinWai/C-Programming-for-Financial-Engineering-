//Level 9: Introductory Computational Finance
//Groups A&B: Exact Pricing Methods
//A. Exact Solutions of One-Factor Plain Options
//Base class for price calculating functions.

#include "Base.hpp"

Base::Base()
{
	//Default constructor
}

Base::Base(const Base& source)
{
	//Copy constructor
}

Base::~Base()
{
	//Destructor
}

//Assignment operator
Base& Base::operator=(const Base& source)
{
	if (this == &source)
	{
		return *this;
	}

	return *this;
}

//A function for adding more options during run time. 
void Base::More(vector<vector<double>>&c, int s, int e)
{
	double para;					//For inputing parameter. 
	vector<double> rows;		//This vector is to store the input.

	cout << "This is for adding more rows: " << e << endl;
	cout << "Please enter the parameters by following format(remember to use space): T K sigma r S b optType(-1 is put, 1 is call)" << endl;
	cout << "Use enter for a new line's input." << endl;

	for (int a = 0; a < e; a++)
	{
		cout << "adding more options for " << a + 1<<":" << endl;
		
		for (int b = 0; b< s; b++)
		{
			cin >> para;
			rows.push_back(para);
		}
	
		c.push_back(rows);
		rows.clear();
	}

}

